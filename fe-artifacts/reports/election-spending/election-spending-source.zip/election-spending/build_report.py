from pathlib import Path
import csv
import json

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter, MultipleLocator
import numpy as np
from plotly.offline import get_plotlyjs

ROOT = Path(__file__).resolve().parent
BLUE, RED = '#2870B8', '#D35B59'
INK, MUTED, GRID = '#172B3A', '#556571', '#E2E7EB'
BG = '#FAFBFC'


def read_csv(name):
    with (ROOT / 'sources' / name).open(newline='') as stream:
        return list(csv.DictReader(stream))


def dollars(value):
    return int(value.replace('$', '').replace(',', ''))


cpi = {int(r['year']): float(r['cpi_u_annual_average']) for r in read_csv('cpi_annual.csv')}
outside = {int(r['cycle']): {k: int(v) for k, v in r.items()} for r in read_csv('outside_spending_nominal.csv')}
rows = []
for r in read_csv('opensecrets_party_totals_nominal.csv'):
    year = int(r['Cycle'].rstrip('*'))
    if not 2000 <= year <= 2024:
        continue
    d, rep, total, third = [dollars(r[k]) for k in ['Democrats', 'Republicans', 'Total Cost of Election', 'Third Party Candidates']]
    o = outside[year]
    components = sum(o[k] for k in ['independent_expenditures', 'electioneering_communications', 'communication_costs'])
    rows.append(dict(
        cycle=year, cycle_type='Presidential' if year % 4 == 0 else 'Midterm',
        cycle_start=f'{year-1}-01-01', cycle_end=f'{year}-12-31',
        democrats_usd=d, republicans_usd=rep, two_party_total_usd=d+rep,
        national_total_usd=total, third_party_usd=third,
        other_unallocated_usd=total-d-rep-third,
        outside_total_usd=o['total'], independent_expenditures_usd=o['independent_expenditures'],
        electioneering_communications_usd=o['electioneering_communications'],
        communication_costs_usd=o['communication_costs'],
        outside_components_sum_usd=components, outside_component_discrepancy_usd=components-o['total'],
        cpi_u=cpi[year], multiplier_2024_dollars=cpi[2024]/cpi[year],
        democrats_2024_usd=round(d*cpi[2024]/cpi[year]),
        republicans_2024_usd=round(rep*cpi[2024]/cpi[year]),
    ))
rows.sort(key=lambda r: r['cycle'])
if [r['cycle'] for r in rows] != list(range(2000, 2025, 2)):
    raise ValueError('Missing or duplicate election cycle')
if any(r['other_unallocated_usd'] < 0 for r in rows):
    raise ValueError('Negative residual in the national cost series')
with (ROOT / 'election_spending_2000_2024.csv').open('w', newline='') as stream:
    writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
    writer.writeheader()
    writer.writerows(rows)
(ROOT / 'data.json').write_text(json.dumps(rows, indent=2))

plt.rcParams.update({
    'font.family': 'DejaVu Sans', 'font.size': 11,
    'text.color': INK, 'axes.labelcolor': MUTED,
    'xtick.color': MUTED, 'ytick.color': MUTED,
    'savefig.facecolor': BG, 'figure.facecolor': BG,
    'axes.facecolor': BG, 'svg.fonttype': 'none', 'pdf.fonttype': 42,
})
years = np.arange(len(rows))


def setup_axes(ax, ymax, step):
    for i, r in enumerate(rows):
        if r['cycle_type'] == 'Presidential':
            ax.axvspan(i-.46, i+.46, color='#EEF2F5', zorder=0)
    ax.set_ylim(0, ymax)
    ax.set_xlim(-.65, len(rows)-.35)
    ax.set_xticks(years, [f"{r['cycle']}\n{'P' if r['cycle_type']=='Presidential' else 'M'}" for r in rows])
    ax.tick_params(axis='both', length=0, pad=10)
    ax.yaxis.set_major_locator(MultipleLocator(step))
    ax.yaxis.set_major_formatter(FuncFormatter(lambda v, pos: f'${v:g}B'))
    ax.yaxis.grid(True, color=GRID, linewidth=.8)
    ax.set_axisbelow(True)
    for spine in ax.spines.values():
        spine.set_visible(False)
    ax.axhline(0, color='#BDC8D0', linewidth=1)


def party_chart(adjusted=False):
    fig, ax = plt.subplots(figsize=(16, 9), dpi=160)
    fig.subplots_adjust(left=.065, right=.975, bottom=.245, top=.76)
    unit = '2024 dollars, adjusted using annual CPI-U' if adjusted else 'Reported dollars, not adjusted for inflation'
    fig.text(.065, .935, 'Federal election spending by party', fontsize=26, weight='bold')
    fig.text(.065, .885, '2000–2024  •  Two-year cycles  •  President, House and Senate', fontsize=14, color=MUTED)
    fig.text(.065, .84, unit, fontsize=12, color=MUTED)
    for offset, key, color, label in [(-.19, 'democrats_usd', BLUE, 'Democrats'), (.19, 'republicans_usd', RED, 'Republicans')]:
        vals = np.array([r[key]*(r['multiplier_2024_dollars'] if adjusted else 1)/1e9 for r in rows])
        bars = ax.bar(years+offset, vals, width=.34, color=color, zorder=3, label=label)
        for bar, val in zip(bars, vals):
            ax.text(bar.get_x()+bar.get_width()/2, val+.11, f'{val:.2f}', ha='center', va='bottom', fontsize=10, color=color, weight='medium')
    setup_axes(ax, 11.7 if adjusted else 9.5, 2)
    ax.legend(loc='upper left', bbox_to_anchor=(.002, 1.08), ncol=2, frameon=False, fontsize=12, handlelength=1.2)
    fig.text(.065, .175, 'P = presidential cycle, including congressional races.  M = midterm cycle.  Labels show billions of dollars.', color=MUTED, fontsize=11)
    fig.text(.065, .125, 'Includes candidates, party committees and reported outside spending, including Super PACs. Major transfers are removed to avoid double counting.', fontsize=10)
    fig.text(.065, .093, 'Federal elections only; excludes unreported activity. Party amounts use OpenSecrets attribution; third-party and unallocated spending are omitted.', fontsize=10)
    fig.text(.065, .061, 'Coverage changes: detailed method from 2010; PAC overhead from 2014; joint fundraising committee overhead from 2022.', fontsize=10, color=MUTED)
    fig.text(.065, .025, 'Source: OpenSecrets, Cost of Election. Retrieved Oct. 19, 2026.' + (' Inflation: Minneapolis Fed / BLS annual CPI-U.' if adjusted else ''), fontsize=9, color=MUTED)
    stem = 'party_spending_2024_dollars' if adjusted else 'party_spending_reported_dollars'
    for extension in ['png', 'svg', 'pdf']:
        fig.savefig(ROOT / f'{stem}.{extension}', dpi=180)
    plt.close(fig)


def outside_chart():
    fig, ax = plt.subplots(figsize=(16, 8), dpi=160)
    fig.subplots_adjust(left=.065, right=.975, bottom=.24, top=.73)
    fig.text(.065, .93, 'The rise of reported outside spending', fontsize=25, weight='bold')
    fig.text(.065, .875, 'All party alignments  •  Excludes party committees  •  Billions of reported dollars', fontsize=13, color=MUTED)
    bottom = np.zeros(len(rows))
    for key, color, label in [
        ('independent_expenditures_usd', '#6874B8', 'Independent expenditures¹'),
        ('electioneering_communications_usd', '#D4A04E', 'Electioneering communications'),
        ('communication_costs_usd', '#5A9D97', 'Communication costs'),
    ]:
        vals = np.array([r[key]/1e9 for r in rows])
        ax.bar(years, vals, width=.58, bottom=bottom, color=color, label=label, zorder=3)
        bottom += vals
    setup_axes(ax, 4.8, 1)
    for x, val in zip(years, bottom):
        ax.text(x, val+.065, f'{val:.2f}', ha='center', fontsize=10)
    ax.legend(loc='upper left', bbox_to_anchor=(.002, 1.15), ncol=3, frameon=False, fontsize=11, handlelength=1.1)
    fig.text(.065, .168, '¹ Includes spending by Super PACs and other groups. These are expenditure types, not original donor sources.', fontsize=11)
    fig.text(.065, .122, 'This series overlaps with the broad election-cost estimate; do not add it to the party bars. Separate snapshots may not reconcile.', fontsize=10)
    fig.text(.065, .085, 'The 2012 components sum to $66,912 more than the source total; bars use the components. P = presidential cycle; M = midterm.', fontsize=10, color=MUTED)
    fig.text(.065, .035, 'Source: OpenSecrets, Outside Spending by Election Cycle, excluding party committees. Retrieved Oct. 19, 2026.', fontsize=9, color=MUTED)
    for extension in ['png', 'svg', 'pdf']:
        fig.savefig(ROOT / f'outside_spending_by_type.{extension}', dpi=180)
    plt.close(fig)


party_chart()
party_chart(adjusted=True)
outside_chart()
template = (ROOT / 'report_template.html').read_text()
template = template.replace('__PLOTLY_LIBRARY__', get_plotlyjs()).replace('__ELECTION_DATA__', json.dumps(rows))
(ROOT / 'election_spending_report.html').write_text(template)
print(json.dumps({
    'cycles': len(rows),
    '2024': rows[-1],
    'outside_component_discrepancies': [{k:r[k] for k in ['cycle', 'outside_component_discrepancy_usd']} for r in rows if r['outside_component_discrepancy_usd']],
    'output': str(ROOT / 'election_spending_report.html'),
}, indent=2))
